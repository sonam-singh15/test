package com.stackroute.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/* Annotate the class with @Entity annotation*/
@Entity
public class Employee {

	/* id is annotated with @Id */
	@Id
	private String code;
    private String name;
    private String gender;
    private int annualSalary;
    private String dateofbirth;

	@Override
	public String toString() {
		return "Employee [code=" + code + ", name=" + name + ", gender=" + gender + ", annualSalary=" + annualSalary
				+ ", dateofbirth=" + dateofbirth + "]";
	}

	public Employee(String code, String name, String gender, int annualSalary, String dateofbirth) {
		super();
		this.code = code;
		this.name = name;
		this.gender = gender;
		this.annualSalary = annualSalary;
		this.dateofbirth = dateofbirth;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(int annualSalary) {
		this.annualSalary = annualSalary;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public Employee() {
	}

	

}
