package com.stackroute.exceptions;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException() {
	}

	public EmployeeNotFoundException(String message) {
		super(message);
	}
}
