package com.example.PatientExceptions;

public class PatientDoesNotExistException {

}
