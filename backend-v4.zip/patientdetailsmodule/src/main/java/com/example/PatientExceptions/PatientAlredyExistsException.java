package com.example.PatientExceptions;

public class PatientAlredyExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientAlredyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
