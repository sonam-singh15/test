package com.example.PatientService;

import com.example.PatientModel.PatientEmergencyDetails;

public interface EmergencyDetailsService {
	
	PatientEmergencyDetails save(PatientEmergencyDetails patientEmergencyDetails);
}
