package com.example.PatientService;

import com.example.PatientModel.Address;

public interface AddressService {
	
	Address save(Address address);
}
