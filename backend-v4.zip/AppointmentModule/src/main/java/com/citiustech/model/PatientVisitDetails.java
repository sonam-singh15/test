package com.citiustech.model;


public class PatientVisitDetails {

	
}
