package com.citiustech.DTO;

public class PhysicianDTO {

}
