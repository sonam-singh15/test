import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nurse-dashboard',
  templateUrl: './nurse-dashboard.component.html',
  styleUrls: ['./nurse-dashboard.component.css']
})
export class NurseDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
