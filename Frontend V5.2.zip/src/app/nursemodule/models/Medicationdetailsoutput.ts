
export class MedicationDetailsOutput {
  id?:number;
    meetingid?:number;
  drug_id?:string;
    drug_name ?:string;
    drug_generic_name?:string;
    drug_brand_name?:string;
    drug_form ?:string;
 
      
 
 
 
   
 }
 