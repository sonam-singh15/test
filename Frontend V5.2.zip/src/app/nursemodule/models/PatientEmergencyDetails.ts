export class PatientEmergencyDetails{
    // patient_emergency_contact_id? :number;
    first_name?: string;
	last_name?: string;
    email?:string;
	relationship?: string;
	phone?: string;
	address?: string;
    // patient_id ?:number;
	// access_allow?: boolean
}