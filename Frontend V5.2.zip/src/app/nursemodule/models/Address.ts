export class Address{
    line1:string;
    line2:string;
    postalcode:string;
    city:string;
    state:string;
    country:string;

    constructor(){
        this.line1='';
        this.line2='';
        this.postalcode='';
        this.city='';
        this.state='';
        this.country='';
    }
}