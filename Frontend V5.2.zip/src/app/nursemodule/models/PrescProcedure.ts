export class PrescProcedure {
    procedureCode:string;
    procedureDescription:string;
    procedureIsDepricated:string;
   meeting_id: any;
     constructor() {
        this.procedureCode=''
        this.procedureDescription=''
        this.procedureIsDepricated=''
        this.meeting_id=0;
    }



  
}
