export class PrescDiagnosis {
    diagnosisCode:string;
    diagnosisDescription:string;
    diagnosisIsDepricated:string;
    meeting_id:number;
     constructor() {
        this.diagnosisCode=''
        this.diagnosisDescription=''
        this.diagnosisIsDepricated=''
        this.meeting_id=0;
    }



  
}
