import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldappointments',
  templateUrl: './oldappointments.component.html',
  styleUrls: ['./oldappointments.component.css']
})
export class OldappointmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
