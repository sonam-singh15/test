import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abouthospital',
  templateUrl: './abouthospital.component.html',
  styleUrls: ['./abouthospital.component.css']
})
export class AbouthospitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
