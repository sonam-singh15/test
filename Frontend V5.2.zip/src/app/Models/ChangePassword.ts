export class changePassword {
    email:string;
    oldpassword:string;
    newpassword:string;
    
 

    constructor() {
        this.email=''
        this.oldpassword=''
        this.newpassword=''
        
        
    }
}
