

export class PatientVisitDetails {
    meetingid:number;
    first_name:string;
    physician:string;
    height:number;
    weight:number;
    bloodpressure:string;
    bodytemperature:number;
    respirationrate:number;

     constructor() {
         this.meetingid=0
        this.first_name=''
        this. physician=''
        this.height=0
        this.weight=0;
        this.bloodpressure=''
        this.bodytemperature=0
        this.respirationrate=0
    }



  
}
