export class LoginUser{
    usernameOrEmail: string;
    password: string;

    constructor(){
        this.usernameOrEmail=''
        this.password=''
    }

    


}