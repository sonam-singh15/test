
	export class AppointmentBookingPatient {
    MeetingTitle?:string;
    description ?:string;
    phy_id ?:number;
    dateofappointment?:string;
    timeofappontment?:string;
	reason?:string
    }