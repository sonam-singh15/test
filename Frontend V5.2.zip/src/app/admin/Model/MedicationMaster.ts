export class MedicationMaster {
  drug_id :string;
  drug_name :string;
  drug_generic_name:string;
  drug_brand_name:string;
  drug_form :string;

     constructor() {
        this.drug_id=''
        this.drug_name=''
        this.drug_generic_name=''
        this.drug_brand_name=''
        this.drug_form=''
    }



  
}
