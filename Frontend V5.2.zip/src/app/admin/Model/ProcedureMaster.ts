
export class ProcedureMaster {
    procedureCode :string;
    procedureDescription:string; 
    procedureIsDepricated :Boolean;
    id:number;
    
        
         constructor() {
         this.procedureCode=''
         this.procedureDescription=''
         this.procedureIsDepricated=false
         this.id=0
          
           
        }
    
    
    
      
    }
    