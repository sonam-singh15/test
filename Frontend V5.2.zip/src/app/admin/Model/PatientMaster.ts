
export class PatientMaster {
  patient_id: string;
  title: string;
  firstname: string;
  lastname: string;
  email: string;
  dob: string;
  password: string;

  constructor() {
      this.patient_id = '';
      this.title = ''
      this.firstname = ''
      this.lastname = ''
      this.email = ''
      this.dob = ''
      this.password = ''

  }




}
