
export class DiagnosisMaster {
    diagnosisCode:string;
    diagnosisDescription:string; 
    diagnosisIsDepricated:Boolean;
    id:number;

     constructor() {
     this.diagnosisCode=''
     this.diagnosisDescription=''
     this.diagnosisIsDepricated=false
     this.id=0
    
    }




  
}
