import { ActivestatusPipe } from './activestatus.pipe';

describe('ActivestatusPipe', () => {
  it('create an instance', () => {
    const pipe = new ActivestatusPipe();
    expect(pipe).toBeTruthy();
  });
});
