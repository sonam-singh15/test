import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-history-modal',
  templateUrl: './edit-history-modal.component.html',
  styleUrls: ['./edit-history-modal.component.css']
})
export class EditHistoryModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
