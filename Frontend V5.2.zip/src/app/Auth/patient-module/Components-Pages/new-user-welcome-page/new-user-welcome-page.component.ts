import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-user-welcome-page',
  templateUrl: './new-user-welcome-page.component.html',
  styleUrls: ['./new-user-welcome-page.component.css']
})
export class NewUserWelcomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
