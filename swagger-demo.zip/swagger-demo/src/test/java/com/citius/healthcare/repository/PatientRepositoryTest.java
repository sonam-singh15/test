package com.citius.healthcare.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.citius.healthcare.model.Patient;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
class PatientRepositoryTest {
	
	@Autowired
	private PatientRepository patientRepository;
	private Patient patient;

	@BeforeEach
	void setUp() throws Exception {
		patient = new Patient("PT010", "abc@gmail.com", "Adam", "M");
	}

	@Test
	public void addCustomerTest() {
		patientRepository.save(patient);
		Patient p = patientRepository.findById(patient.getPatient_id()).get();
		assertEquals("PT010",p.getPatient_id());
	}
}
