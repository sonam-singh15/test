package com.citius.healthcare.service;

import java.util.List;

import com.citius.healthcare.exceptions.PatientAlreadyExists;
import com.citius.healthcare.exceptions.PatientEmailAlreadyExists;
import com.citius.healthcare.model.Patient;

public interface PatientService {
	
	Patient findByEmail(String email);
	Patient addPatient(Patient p) throws PatientAlreadyExists, PatientEmailAlreadyExists;
	List<Patient> retrievePatients();
}
