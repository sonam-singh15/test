package com.citius.healthcare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citius.healthcare.exceptions.PatientAlreadyExists;
import com.citius.healthcare.exceptions.PatientEmailAlreadyExists;
import com.citius.healthcare.model.Patient;
import com.citius.healthcare.service.PatientService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value="This is the Patient controller with endpoints of POST, GET, PUT request")
@RestController
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	
	@ApiOperation(value="POST Call", response = Patient.class, tags="Registering Patient")
	@PostMapping("/addpatient")
	public ResponseEntity<Patient> addPatient(@RequestBody Patient patient) throws PatientAlreadyExists, PatientEmailAlreadyExists {
		Patient temp = patientService.addPatient(patient);
		return new ResponseEntity<Patient>(temp,HttpStatus.CREATED);
	}
	
	@GetMapping("/getpatients")
	public ResponseEntity<List<Patient>> retrievePatients() throws PatientAlreadyExists, PatientEmailAlreadyExists {
		return new ResponseEntity<List<Patient>>(patientService.retrievePatients(),HttpStatus.OK);
	}

}
