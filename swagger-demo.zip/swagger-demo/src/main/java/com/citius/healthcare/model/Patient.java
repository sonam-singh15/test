package com.citius.healthcare.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.Check;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Length;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("This is Patient Model for the healtcare app")
@Entity
@Table(name = "patients")
public class Patient {
	
	@ApiModelProperty(notes="This is the primary key for generating the Patient ID")
	@Id
	//@GenericGenerator(name="seq_id", strategy = "com.citius.healthcare.utility.PatientIdGenerator")
	//@GeneratedValue(generator="seq_id")
	private String patient_id;
	
	@ApiModelProperty(notes="Capturing the patient email ID. Should be unique")
	private String email;
	
	private String firstname;
	private String lastname;
	public String getPatient_id() {
		return patient_id;
	}
	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Patient(String patient_id, String email, String firstname, String lastname) {
		super();
		this.patient_id = patient_id;
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
	}
	
	

}
