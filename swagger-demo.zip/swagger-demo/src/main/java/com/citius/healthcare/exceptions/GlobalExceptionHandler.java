package com.citius.healthcare.exceptions;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler(value=PatientAlreadyExists.class)
	public ResponseEntity<String> patientAlreadyExists(PatientAlreadyExists exception) {
		return new ResponseEntity<String>("Patient id already exists",HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(value=PatientEmailAlreadyExists.class)
	public ResponseEntity<?> patientEmailAlreadyExist(PatientEmailAlreadyExists exception, WebRequest request) {
		return new ResponseEntity<String>("Patient emailid already exists",HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(value=PatientNotExists.class)
	public ResponseEntity<String> customerNotExist(PatientNotExists exception) {
		return new ResponseEntity<String>("Patient not exist", HttpStatus.CONFLICT);
	}


}
