package com.citius.healthcare.exceptions;

public class PatientNotExists extends Exception {

}
