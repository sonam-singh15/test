package com.citius.healthcare.exceptions;

public class PatientEmailAlreadyExists extends Exception {

}
