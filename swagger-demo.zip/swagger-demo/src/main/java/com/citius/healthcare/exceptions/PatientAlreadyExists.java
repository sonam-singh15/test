package com.citius.healthcare.exceptions;

public class PatientAlreadyExists extends Exception {

}
