package com.citius.healthcare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citius.healthcare.exceptions.PatientAlreadyExists;
import com.citius.healthcare.exceptions.PatientEmailAlreadyExists;
import com.citius.healthcare.model.Patient;
import com.citius.healthcare.repository.PatientRepository;


@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	private PatientRepository patientRepository;

	@Override
	public Patient findByEmail(String email) {
		return patientRepository.findByEmail(email);
	}

	@Override
	public Patient addPatient(Patient p) throws PatientAlreadyExists, PatientEmailAlreadyExists {
		 if(patientRepository.findByEmail(p.getEmail()) != null) {
			System.out.println(p.getEmail());
			throw new PatientEmailAlreadyExists();
		} else {
			return patientRepository.save(p);
		}
	}

	@Override
	public List<Patient> retrievePatients() {
		// TODO Auto-generated method stub
		return (List<Patient>) patientRepository.findAll();
	}

}
