package com.citiustech.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.exception.BookAlreadyExistsException;
import com.citiustech.model.Book;
import com.citiustech.repo.BookRepo;
import com.citiustech.service.BookService;
import com.citiustech.utility.GetCategoryDTO;

@RestController
@RequestMapping("/book/api")
public class BookController {
	@Autowired
	private BookService bookService;
	@Autowired
	private BookRepo bookrepo;

	@GetMapping("/book")
	public ResponseEntity<List<Book>> getListOfUsers() {
		return new ResponseEntity<List<Book>>(bookService.getListOfBooks(), HttpStatus.OK);
	}

	@PostMapping("/book")
	public ResponseEntity<Book> saveBook(@RequestBody Book b) {
		if (bookrepo.getBookByName(b.getName()) != null) {
			throw new BookAlreadyExistsException("Book already exists with Book name: " + b.getName());

		} else {
		Book b1 = bookService.saveBook(b);
		return new ResponseEntity<Book>(b1, HttpStatus.CREATED);
		}

	}

	@DeleteMapping("/book/{id}")
	public ResponseEntity<Book> deleteBook(@PathVariable int id) {
		bookService.deleteBook(id);
		return new ResponseEntity<Book>(HttpStatus.OK);
	}

	@PutMapping("/book/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book b) {
		Book b2 = bookService.updateBook(id, b);
		return new ResponseEntity<Book>(b2, HttpStatus.OK);
	}

	@GetMapping("book/{name}")
	public ResponseEntity<Book> getBookByName(@PathVariable String name) {
		Book temp = bookService.getBookByName(name);
		return new ResponseEntity<Book>(temp, HttpStatus.OK);
	}

	@GetMapping("book/category/{category}")
	public ResponseEntity<List<GetCategoryDTO>> getBookByCategory(@PathVariable String category) {
		List<GetCategoryDTO> b = bookService.getBookByCategory(category);
		return new ResponseEntity<List<GetCategoryDTO>>(b, HttpStatus.OK);
	}

	@GetMapping("/book/price")
	public ResponseEntity<List<Book>> getBooksDescOrder() {
		return new ResponseEntity<List<Book>>(bookService.getBooksDescOrder(), HttpStatus.OK);
	}

}
