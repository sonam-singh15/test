package com.citiustech.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspect {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Before(value = "execution(* com.citiustech..*(..))")
	public void beforeExecution(JoinPoint joinPoint) {

		logger.info("Method name: " + joinPoint.getSignature().getName());
		logger.info("Method Arguments: " + Arrays.toString(joinPoint.getArgs()));
		logger.info("-------------------------------------------------------");
	}

	@Around(value = "execution(* com.citiustech..*(..))")
	public Object duringExecution(ProceedingJoinPoint joinPoint) throws Throwable {

		logger.info("Method name: " + joinPoint.getSignature().getName());
		logger.info("Method Arguments: " + Arrays.toString(joinPoint.getArgs()));
		logger.info("-------------------------------------------------------");
		// to return Array of objects
		Object result = joinPoint.proceed();

		logger.info("During: {}.{}() with argument[s]={}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), result);
		logger.info("-------------------------------------------------------");

		logger.info("After Method name: " + joinPoint.getSignature().getName());
		return result;
	}

	@After(value = "execution(* com.citiustech..*(..))")
	public void afterExecution(JoinPoint joinPoint) {
		logger.info("After Method name: " + joinPoint.getSignature().getName());
		logger.info("-------------------------------------------------------");
	}

	@AfterThrowing(value = "execution(* com.citiustech..*(..))", throwing = "ex")
	public void afterExceptionThrown(JoinPoint joinPoint, Throwable ex) {

		logger.error("Target Method resulted into exception, message {}", ex.getMessage());

		logger.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), ex.getCause() != null ? ex.getCause() : "null");
	}
}
