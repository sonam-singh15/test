package com.citiustech.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.citiustech.model.Book;
import com.citiustech.repo.BookRepo;
import com.citiustech.utility.GetCategoryDTO;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepo bookRepo;

	@Override
	public List<Book> getListOfBooks() {
		return (List<Book>) bookRepo.findAll();
	}

	@Override
	public Book saveBook(Book book) {
		return bookRepo.save(book);
	}

	@Override
	public Book deleteBook(int id) {
		Book temp = bookRepo.findById(id).orElse(null);
		if (temp != null) {
			bookRepo.deleteById(id);
			temp = bookRepo.findById(id).orElse(null);
		}
		return temp;

	}

	@Override
	public Book updateBook(int id, Book book) {
		Optional<Book> temp = bookRepo.findById(id);
		Book foundBook = temp.get();
		foundBook.setAuthor(book.getAuthor());
		foundBook.setCategory(book.getCategory());
		foundBook.setName(book.getName());
		foundBook.setPrice(book.getPrice());
		Book updateBook = bookRepo.save(foundBook);
		return updateBook;
	}

	@Override
	public Book getBookByName(String name) {
		return (Book) bookRepo.getBookByName(name);

	}

	@Override
	public List<Book> getBooksDescOrder() {
		return (List<Book>) bookRepo.findAll(Sort.by(Sort.Direction.DESC, "price"));
	}

	@Override
	public List<GetCategoryDTO> getBookByCategory(String category) {
		List<GetCategoryDTO> cat = bookRepo.findByCategory(category);
		return cat;
	}

}
