package com.citiustech.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.citiustech.model.Book;
import com.citiustech.utility.GetCategoryDTO;

public interface BookService {
	public List<Book> getListOfBooks();

	public Book saveBook(Book book);

	public Book updateBook(int id, Book book);

	public Book deleteBook(int id);

	public Book getBookByName(String name);

	public List<GetCategoryDTO> getBookByCategory(String category);

	public List<Book> getBooksDescOrder();

}
