package com.citiustech.repo;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.model.Book;
import com.citiustech.utility.GetCategoryDTO;

@Repository
public interface BookRepo extends CrudRepository<Book, Integer> {

	@Query("select b from Book b where b.name=?1")
	Book getBookByName(String name);

	@Query("SELECT new com.citiustech.utility.GetCategoryDTO( b.name,b.author) from Book b where b.category=?1")
	List<GetCategoryDTO> findByCategory(String category);

//	@Query("select b from Book order by b.price desc;")
//	Book getBookSortedByprice();

	List<Book> findAll(Sort by);

}
