package com.citiustech.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.citiustech.model.Book;
import com.citiustech.service.BookService;
import com.citiustech.utility.GetCategoryDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
public class BookControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@Mock
	private BookService bookService;
	private Book book;
	private List<Book> blist;
	private List<GetCategoryDTO> clist;

	@InjectMocks
	private BookController bookController;

	@BeforeEach
	void setUp() throws Exception {
		book = new Book(1, "abc", "Ben", "fiction", 1500);
		mockMvc = MockMvcBuilders.standaloneSetup(bookController).build();

	}

	@Test
	public void saveBookTest() throws Exception {
		when(bookService.saveBook(any())).thenReturn(book);
		mockMvc.perform(post("/book/api/book").contentType(MediaType.APPLICATION_JSON).content(asJsonString(book)))
				.andExpect(status().isCreated());
		verify(bookService, times(1)).saveBook(any());
	}

	@Test
	public void getAllBooksTest() throws Exception {
		when(bookService.getListOfBooks()).thenReturn(blist);
		mockMvc.perform(MockMvcRequestBuilders.get("/book/api/book").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(book))).andDo(MockMvcResultHandlers.print());
		verify(bookService).getListOfBooks();

	}

	@Test
	void getBookByNameTest() throws Exception {
		when(bookService.getBookByName(book.getName())).thenReturn(book);
		mockMvc.perform(get("/book/api/book/abc")).andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print());

	}

	@Test
	void getBooksDescOrderTest() throws Exception {
		when(bookService.getBooksDescOrder()).thenReturn(blist);
		mockMvc.perform(get("/book/api/book/price")).andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print());

	}

	@Test
	void getBooksCategorywiseTest() throws Exception {
		when(bookService.getBookByCategory(book.getCategory())).thenReturn(clist);
		mockMvc.perform(get("/book/api/book/category/fiction")).andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print());

	}

	@Test
	public void updateBookTest() throws Exception {
		when(bookService.updateBook(anyInt(), any())).thenReturn(book);
		mockMvc.perform(put("/book/api/book/1").contentType(MediaType.APPLICATION_JSON).content(asJsonString(book)))
				.andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
	}

	@Test
	public void deleteBookTest() throws Exception {
		bookService.deleteBook(book.getId());
		mockMvc.perform(delete("/book/api/book/1").contentType(MediaType.APPLICATION_JSON).content(asJsonString(book)))
				.andExpect(MockMvcResultMatchers.status().isOk()).andDo(MockMvcResultHandlers.print());
	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException();
		}
	}

}
