package com.citiustech.repo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.citiustech.model.Book;

@SpringBootTest
public class BookRepoTest {
	@Autowired
	private BookRepo bookRepo;
	private Book book;

	@BeforeEach
	public void setUp() {
		book = new Book();
		book.setId(1);
		book.setName("abc");
		book.setAuthor("Ben");
		book.setCategory("fiction");
		book.setPrice(1500);
	}

	@AfterEach
	public void tearDown() {
		bookRepo.deleteAll();
		book = null;
	}

	@Test
	public void saveBookTest() {
		bookRepo.save(book);
		Book fetchedBook = bookRepo.findById(book.getId()).get();
		assertEquals(1, fetchedBook.getId());
	}

	@Test
	public void givenGetAllBooksTest() {
		Book book = new Book(1, "abc", "Ben", "fiction", 1500);
		Book book1 = new Book(2, "pqr1", "dgfs", "fiction", 1700);
		bookRepo.save(book);
		bookRepo.save(book1);

		List<Book> booklist = (List<Book>) bookRepo.findAll();
		assertEquals("abc", booklist.get(1).getName());
	}

	@Test
	public void givenBookIdTest() {
		Book book = new Book(1, "abc", "Ben", "fiction", 1500);
		Book book1 = bookRepo.save(book);
		Optional<Book> optional = bookRepo.findById(book.getId());
		assertEquals(book1.getId(), optional.get().getId());
		assertEquals(book1.getName(), optional.get().getName());
		assertEquals(book1.getCategory(), optional.get().getCategory());
		assertEquals(book1.getPrice(), optional.get().getPrice());
	}

	@Test
	public void givenBookIdToDeleteTest() {
		Book book = new Book(1, "abc", "Ben", "fiction", 1500);
		bookRepo.save(book);
		bookRepo.deleteById(book.getId());
		Optional optional = bookRepo.findById(book.getId());
		assertEquals(Optional.empty(), optional);
	}

}
