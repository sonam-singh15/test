package com.citiustech.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.model.Book;
import com.citiustech.repo.BookRepo;

@ExtendWith(MockitoExtension.class)
public class BookServiceTest {
	@Mock
	private BookRepo bookRepo;

	@InjectMocks
	private BookServiceImpl bookService;

	private Book book, book1;
	private List<Book> list;

	@BeforeEach
	public void setup() {
		book = new Book(1, "abc", "Ben", "fiction", 1500);
		book1 = new Book(2, "pqr1", "dgfs", "fiction", 1700);

		list = new ArrayList<>();
		list.add(book);
		list.add(book1);

	}

	@Test
	public void testSave() {
		Book book = new Book(1, "abc", "Ben", "fiction", 1500);
		when(bookRepo.save(any())).thenReturn(book);
		bookService.saveBook(book);
		bookService.saveBook(book);
		verify(bookRepo, times(2)).save(book);
	}

	@Test
	public void testGetAllBooks() {
		Book b1 = new Book(1, "abc", "Ben", "fiction", 1500);
		Book b2 = new Book(2, "pqr1", "dgfs", "fiction", 1700);
		bookRepo.save(b1);
		bookRepo.save(b1);
		List<Book> blist = new ArrayList<>();
		blist.add(b1);
		blist.add(b2);

		when(bookRepo.findAll()).thenReturn(blist);
		List<Book> temp = bookService.getListOfBooks();
		assertEquals(blist, temp);

	}

	@Test
	public void testDeleteBook() {
		when(bookRepo.findById(book.getId())).thenReturn(Optional.of(book));
		Book deletedBook = bookService.deleteBook(1);
		assertEquals(1, deletedBook.getId());
		verify(bookRepo, times(2)).findById(book.getId());
		verify(bookRepo, times(1)).deleteById(book.getId());

	}

	@Test
	public void testUpdateBook() {
		when(bookRepo.findById(book1.getId())).thenReturn(Optional.of(book1));
		Book updatedbook = bookService.updateBook(book1.getId(), book1);
		assertEquals("pqr1", updatedbook.getName());
		verify(bookRepo, times(2)).findById(book1.getId());
		verify(bookRepo, times(1)).save(book1);

	}

}
