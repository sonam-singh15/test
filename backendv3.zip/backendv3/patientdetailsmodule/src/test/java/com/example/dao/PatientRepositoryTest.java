package com.example.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.PatientModel.PatientRegistrationDetails;
import com.example.Patientdao.PatientRepository;
@ActiveProfiles("test")
@ExtendWith(SpringExtension.class)
@SpringBootTest
class PatientRepositoryTest {
	@Autowired
	PatientRepository patientRepository;
	private PatientRegistrationDetails patientRegistrationDetails;
	
	@BeforeEach
	void setUp() throws Exception {
//		patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");

	}



	@Test
	public void testSavePatient() {
		patientRepository.save(patientRegistrationDetails);


		patientRepository.findByEmail(patientRegistrationDetails.getEmail());

		assertEquals("abc@gmail.com", patientRegistrationDetails.getEmail());
		
	}
	@Test
	public void getAllPatientTest()  {
		
		
//		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		PatientRegistrationDetails patientRegistrationDetails2 = new PatientRegistrationDetails(2,"eabc@gmail.com",1934567899,"qwerty",true,"2022-03-01");
//		PatientRegistrationDetails patientRegistrationDetails3 = new PatientRegistrationDetails(3,"eabc@gmail.com",1434567899,"qwerty",true,"2022-03-01");

		patientRepository.save(patientRegistrationDetails);
//		patientRepository.save(patientRegistrationDetails2);
//		patientRepository.save(patientRegistrationDetails3);

		  List<PatientRegistrationDetails> fetchedList = patientRepository.findAll();
		  assertEquals(1, fetchedList.get(0).getPatient_id());	
	}
	@Test
	void testFindByEmail() {
//		PatientRegistrationDetails patient = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//	PatientRegistrationDetails Patient1= patientRepository.save(patient);
//	patientRepository.getPatientByPatientemail(Patient1.getEmail());
//	assertEquals("abc@gmail.com",Patient1.getEmail());
	}
}
