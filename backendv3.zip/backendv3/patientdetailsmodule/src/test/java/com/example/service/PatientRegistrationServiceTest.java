package com.example.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import com.example.PatientExceptions.PatientAlredyExistsException;
import com.example.PatientModel.PatientRegistrationDetails;
import com.example.PatientService.PatientRegistrationServiceImpl;
import com.example.Patientdao.PatientRepository;
@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
class PatientRegistrationServiceTest {
	@Autowired
	private MockMvc mockMvc;
	@Mock
	PatientRepository patientRepository;
	
	@InjectMocks
	private PatientRegistrationServiceImpl patientRegistrationService;


	@Test
	void testSavePatient() throws PatientAlredyExistsException {
//		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
		
//        when(patientRepository.save(any())).thenReturn(patientRegistrationDetails);  
//        patientRegistrationService.savePatient(patientRegistrationDetails);
//        patientRegistrationService.savePatient(patientRegistrationDetails);
//        verify(patientRepository,times(2)).save(patientRegistrationDetails);
	}

	@Test
	void testGetAllPatients() {
//		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		PatientRegistrationDetails patientRegistrationDetails2 = new PatientRegistrationDetails(2,"eabc@gmail.com",1934567899,"qwerty",true,"2022-03-01");
//		patientRepository.save(patientRegistrationDetails);
//		patientRepository.save(patientRegistrationDetails2);
//		
//		List<PatientRegistrationDetails> clist = new ArrayList<>();
//		clist.add(patientRegistrationDetails);
//		clist.add(patientRegistrationDetails2);
		
//		when(patientRepository.findAll()).thenReturn(clist);
//		List<PatientRegistrationDetails> temp = patientRegistrationService.getAllPatients();
//		assertEquals(clist, temp);
//		verify(patientRepository,times(1)).save(patientRegistrationDetails);
//		verify(patientRepository,times(1)).findAll();
	}
	@Test
	public void testUpdatePatient() {
//	PatientRegistrationDetails patient = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//	PatientRegistrationDetails patient1=patient;
//	when(patientRepository.getPatientByPatientemail(any())).thenReturn(patient);
//	patient.setPhone(765);
//
//	patientRegistrationService.updatePatientdetail(patient, "abc@gmail.com");
//	    assertEquals(patient.getPhone(),765);
//	    verify(patientRepository, times(1)).save(patient);
//	      verify(patientRepository,times(1)).getPatientByPatientemail(patient.getEmail());
	    
	}
}
