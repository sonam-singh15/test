//package com.example.dao;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.example.PatientModel.PatientDemographicDetails;
//import com.example.PatientModel.PatientRegistrationDetails;
//@ActiveProfiles("test")
//@ExtendWith(SpringExtension.class)
//@SpringBootTest
//class PatientDemographicDetailsRepositoryTest {
//	@Autowired
//	com.example.Patientdao.PatientDemographicDetailsRepository PatientDemographicDetailsRepository;
//	private PatientDemographicDetails detail;
//	private PatientRegistrationDetails patientRegistrationDetails;
//	@BeforeEach
//	void setUp() throws Exception {
////		patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		
//		detail = new PatientDemographicDetails();
////		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
////		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//	}
//
//
//	@Test
//	public void testSavePatientDetails() {
////		patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		
//		detail = new PatientDemographicDetails();
////		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
////		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//		PatientDemographicDetailsRepository.save(detail);
//
//
//		PatientDemographicDetailsRepository.findById(detail.getPatient_details_id());
//
//		assertEquals(1, detail.getPatient_details_id());
//		
//	}
//	@Test
//	public void getAllPatientDetailsTest()  {
//		
//		
////		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
////		PatientRegistrationDetails patientRegistrationDetails2 = new PatientRegistrationDetails(2,"eabc@gmail.com",1934567899,"qwerty",true,"2022-03-01");
//		PatientDemographicDetails detail = new PatientDemographicDetails();
////		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
//		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//		PatientDemographicDetails detail1 = new PatientDemographicDetails();
////		detail1.setPatient_details_id(2);
////		detail1.setTitle("Mrs");
////		detail1.setFatal(false);
////		detail1.setFirst_name("sonam");
////		detail1.setLast_name("singh");
////		detail1.setBirth_date("12/02/1996");
////		detail1.setAge("24");
////		detail1.setGender("female");
////		detail1.setEmail("eabc@gmail.com");
////		detail1.setPhone("1934567899");
////		detail1.setAddress("mumbai");
////		detail1.setLanguage("english");
////		detail1.setAllergyId("1");
//
////		detail1.setPatientRegistrationDetails(patientRegistrationDetails2);
//		PatientDemographicDetailsRepository.save(detail);
//		PatientDemographicDetailsRepository.save(detail1);
////		patientRepository.save(patientRegistrationDetails3);
//
//		  List<PatientDemographicDetails> fetchedList = PatientDemographicDetailsRepository.findAll();
//		  assertEquals(1, fetchedList.get(0).getPatient_details_id());	
//	}
//
//}
