//package com.example.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.web.servlet.MockMvc;
//
//import com.example.PatientModel.PatientDemographicDetails;
//import com.example.PatientModel.PatientRegistrationDetails;
//import com.example.PatientService.PatientDemographicServiceImpl;
//import com.example.Patientdao.PatientDemographicDetailsRepository;
//@ActiveProfiles("test")
//@ExtendWith(MockitoExtension.class)
//class PatientDemographicDetailsServiceTests {
//	@Autowired
//	private MockMvc mockMvc;
//	@Mock
//	PatientDemographicDetailsRepository patientDemographicDetailsRepository;
//	
//	@InjectMocks
//	private PatientDemographicServiceImpl patientDemographicServiceImpl;
//	@BeforeEach
//
//
//	@Test
//	void testSavePatientDetails() {
////		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		PatientDemographicDetails detail = new PatientDemographicDetails();
////		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("eabc@gmail.com");
////		detail.setPhone("1294567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
////		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//        when(patientDemographicDetailsRepository.save(any())).thenReturn(detail);  
//        patientDemographicServiceImpl.savePatientDetails(detail);
//        patientDemographicServiceImpl.savePatientDetails(detail);
//        verify(patientDemographicDetailsRepository,times(2)).save(detail);	}
//
//	@Test
//	void testGetAllPatientDetails() {
////		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
////		PatientRegistrationDetails patientRegistrationDetails2 = new PatientRegistrationDetails(2,"eabc@gmail.com",1934567899,"qwerty",true,"2022-03-01");
//		PatientDemographicDetails detail = new PatientDemographicDetails();
////		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
////		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//		PatientDemographicDetails detail1 = new PatientDemographicDetails();
////		detail1.setPatient_details_id(2);
////		detail1.setTitle("Mrs");
////		detail1.setFatal(false);
////		detail1.setFirst_name("sonam");
////		detail1.setLast_name("singh");
////		detail1.setBirth_date("12/02/1996");
////		detail1.setAge("24");
////		detail1.setGender("female");
////		detail1.setEmail("eabc@gmail.com");
////		detail1.setPhone("1934567899");
////		detail1.setAddress("mumbai");
////		detail1.setLanguage("english");
////		detail1.setAllergyId("1");
//
////		detail1.setPatientRegistrationDetails(patientRegistrationDetails2);
//		patientDemographicDetailsRepository.save(detail);
//		patientDemographicDetailsRepository.save(detail1);
//		List<PatientDemographicDetails> clist = new ArrayList<>();
//		clist.add(detail);
//		clist.add(detail1);
//		
//		when(patientDemographicDetailsRepository.findAll()).thenReturn(clist);
//		List<PatientDemographicDetails> temp = patientDemographicServiceImpl.getAllPatientDetails();
//		assertEquals(clist, temp);
//
//	}
//	@Test
//	public void testDeleteBook() {
////		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		PatientDemographicDetails detail = new PatientDemographicDetails();
//		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
//	when(patientDemographicDetailsRepository.findById(detail.getPatient_details_id())).thenReturn(Optional.of(detail));
//	PatientDemographicDetails deletedBook = patientDemographicServiceImpl.delete(1);
//	assertEquals(1, deletedBook.getPatient_details_id());
//
//	}
//
//	@Test
//	public void testUpdatePatientDemographicDetsils() {
////		PatientRegistrationDetails patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		PatientDemographicDetails detail = new PatientDemographicDetails();
//		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
//	    Optional optional = Optional.of(detail);
//	    when(patientDemographicDetailsRepository.findById(detail.getPatient_details_id())).thenReturn(optional);
//	    when(patientDemographicDetailsRepository.save(any())).thenReturn(detail);
//	    detail.setAge("27");
//	    patientDemographicServiceImpl.updateUser(1, detail);
//	    assertEquals(detail.getAge(), "27");
//	    verify(patientDemographicDetailsRepository, times(1)).save(detail);
//	    verify(patientDemographicDetailsRepository, times(1)).findById(detail.getPatient_details_id());
//
//	}
//}
