//package com.example.controller;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
//import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//
//import com.example.PatientController.PatientDemographicDetailsController;
//import com.example.PatientModel.PatientDemographicDetails;
//import com.example.PatientModel.PatientRegistrationDetails;
//import com.example.PatientService.PatientDemographicService;
//import com.fasterxml.jackson.databind.ObjectMapper;
//@ActiveProfiles("test")
//@ExtendWith(MockitoExtension.class)
//class PatientDemographicDetailsControllerTest {
//	@Autowired
//	private MockMvc mockMvc;
//	@Mock
//	private PatientDemographicService patientDemographicServiceImpl;
//	private PatientDemographicDetails detail;
//	private PatientRegistrationDetails patientRegistrationDetails;
//	private List<PatientDemographicDetails> patientDemographicDetailsList;
//	
//	@InjectMocks
//	private PatientDemographicDetailsController patientDemographicDetailsControllerTest;
//	
//	@BeforeEach
//	void setUp() throws Exception {
////		patientRegistrationDetails = new PatientRegistrationDetails(1,"abc@gmail.com",1234567899,"qwerty",true,"2022-03-01");
//		
//		detail = new PatientDemographicDetails();
//		detail.setPatient_details_id(1);
////		detail.setTitle("Mrs");
////		detail.setFatal(false);
////		detail.setFirst_name("sonam");
////		detail.setLast_name("singh");
////		detail.setBirth_date("12/02/1996");
////		detail.setAge("24");
////		detail.setGender("female");
////		detail.setEmail("abc@gmail.com");
////		detail.setPhone("1234567899");
////		detail.setAddress("mumbai");
////		detail.setLanguage("english");
////		detail.setAllergyId("1");
////		detail.setPatientRegistrationDetails(patientRegistrationDetails);
//
//
//		mockMvc = MockMvcBuilders.standaloneSetup(patientDemographicDetailsControllerTest).build();
//
//	}
//
////	@AfterEach
////	void tearDown() throws Exception {
////	}
//
//	@Test
//	void testSavePatientRegistration() throws Exception {
//		when(patientDemographicServiceImpl.savePatientDetails(any())).thenReturn(detail);
//		mockMvc.perform(
//				post("/patientdetails").contentType(MediaType.APPLICATION_JSON).content(asJsonString(detail)))
//				.andExpect(status().isCreated());
//		verify(patientDemographicServiceImpl, times(1)).savePatientDetails(any());
//	}
//	@Test
//	void getAllPatientRegistration() throws Exception {
//		when(patientDemographicServiceImpl.getAllPatientDetails()).thenReturn(patientDemographicDetailsList);
//		mockMvc.perform(MockMvcRequestBuilders.get("/patientdetails").contentType(MediaType.APPLICATION_JSON)
//				.content(asJsonString(detail))).andDo(MockMvcResultHandlers.print());
//		verify(patientDemographicServiceImpl).getAllPatientDetails();
//		verify(patientDemographicServiceImpl, times(1)).getAllPatientDetails();
//	}
//	@Test
//	public void updateBookTest() throws Exception {
//	when(patientDemographicServiceImpl.updateUser(anyInt(),any())).thenReturn(detail);
//	mockMvc.perform(put("/patientdetails/1").contentType(MediaType.APPLICATION_JSON)
//	.content(asJsonString(detail))).andExpect(status().isOk());
//	}
//
//	@Test
//	public void deleteBookTest() throws Exception {
//		patientDemographicServiceImpl.delete(detail.getPatient_details_id());
//	    mockMvc.perform(
//	            delete("/patientdetails/102").contentType(MediaType.APPLICATION_JSON).content(asJsonString(detail)))
//	            .andExpect(MockMvcResultMatchers.status().isOk());
//	}
//	public static String asJsonString(final Object obj) {
//		try {
//			return new ObjectMapper().writeValueAsString(obj);
//		} catch (Exception e) {
//			throw new RuntimeException();
//		}
//	}
//
//}
