package com.example.ProviderExceptions;

public class UserdoesntExistException {

}
