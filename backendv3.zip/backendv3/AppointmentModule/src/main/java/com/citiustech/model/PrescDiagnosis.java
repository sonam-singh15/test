package com.citiustech.model;

public class PrescDiagnosis {

}
