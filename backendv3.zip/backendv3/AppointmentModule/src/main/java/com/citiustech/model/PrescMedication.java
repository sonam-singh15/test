package com.citiustech.model;

public class PrescMedication {

}
